import pyotp
import qrcode

# 1. Crear una clave secreta para el servicio
secret = pyotp.random_base32()

# 2. Definir el servicio y el usuario
service_name = "ServicioDemo"
user_name = "alumno@demo.com"

# 3. Crear el objeto TOTP
totp = pyotp.TOTP(secret)

# 4. Generar la URL para Google Authenticator
uri = totp.provisioning_uri(
    name=user_name,
    issuer_name=service_name
)

# 5. Generar el código QR
img = qrcode.make(uri)
img.save("qr_totp.png")

print("QR generado correctamente: qr_totp.png")
print("Clave secreta:", secret)

# 6. Validación del código introducido por el usuario
codigo_usuario = input("Introduce el código TOTP de Google Authenticator: ")

if totp.verify(codigo_usuario):
    print("Código válido ✅")
else:
    print("Código incorrecto ❌")
